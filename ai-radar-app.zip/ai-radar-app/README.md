# 🔥 AI Radar Dashboard

A premarket scanner that finds explosive movers (like QMMM), pulls news catalysts, and generates AI-powered trading playbooks.

## Features
- Premarket % gap and relative volume
- News catalyst detection (via Finnhub API)
- AI trading plan (via OpenAI GPT)

## Run locally
```bash
pip install -r requirements.txt
streamlit run ai_radar.py
```

## Deploy on Streamlit Cloud
1. Create a new app and point it to this repo.
2. Add **App settings → Secrets**:
```toml
OPENAI_API_KEY = "your_openai_key_here"
NEWS_API_KEY   = "your_finnhub_key_here"
```
3. Deploy. You'll get a public link like `https://your-radar-app.streamlit.app`.

## Notes
- Edit the watchlist from the app's text box.
- Free Finnhub key works for basic company headlines.
- OpenAI key is required for AI playbooks.